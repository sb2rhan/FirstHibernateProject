create view purchases_info
            (id, purchase_date, login, password, full_name, title, year_of_publish, author, pages, price) as
SELECT p.id,
       p.purchase_date,
       u.login,
       u.password,
       u.full_name,
       b.title,
       b.year_of_publish,
       b.author,
       b.pages,
       b.price
FROM purchases p
         JOIN users u ON u.id = p.user_id
         JOIN books b ON b.id = p.book_id;

alter table purchases_info
    owner to postgres;

